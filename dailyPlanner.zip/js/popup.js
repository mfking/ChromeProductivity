//to be implemented with history
//the idea being that you can see the detailed breakdown of your productivity if you
//go to the new tab (so the entire entension) but there is a summary no matter
//where you are if you just click on the icon in the tab bar!